# RimFactoryNecerosPatch
 Adds a few new containers
